# Célula [44] -> cálculos manuais:

# Modelo Poisson:

modelo_poisson.params

np.exp(2.212739 -4.296762*0 + 0.021870*23 + 0.341765*0.5)

# Modelo binomial negativo:

modelo_bneg.params

np.exp(1.946894 -4.274618*0 + 0.040018*23 + 0.452662*0.5)

# Modelo ZIP:

modelo_zip.params

(1 - (1/(1 + np.exp(-(-1.611649 -0.952315*0.5)))))*\
    (np.exp(2.488877 + 0.020020*23 + 0.093722*0.5 -4.287916*0))

# Modelo ZINB:

modelo_zinb.params

(1 - (1/(1 + np.exp(-(-17.985682 -8.110426*0.5)))))*\
    (np.exp(2.032397 + 0.041076*23 + 0.181459*0.5 -4.263797*0))
   