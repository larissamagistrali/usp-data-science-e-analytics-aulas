# Modelo OLS:

modelo_linear = sm.OLS.from_formula('violations ~ staff + post + corruption',
                                    df_corruption).fit()

# Parâmetros do 'modelo_linear'
modelo_linear.summary()

#%%
# Teste de Shapiro-Francia nos resíduos do 'modelo_linear'

from statstests.tests import shapiro_francia

shapiro_francia(modelo_linear.resid)

#%%
# Transformação de Box-Cox na variável 'violations'

from scipy.stats import boxcox

yast, lmbda = boxcox(df_corruption['violations'])
# Mensagem de erro!

df_corruption['violations'].describe()

df_corruption['violations1'] = df_corruption['violations'] + 0.001

yast, lmbda = boxcox(df_corruption['violations1'])

df_corruption['bc_violations'] = yast

df_corruption

# Estimação de um novo modelo OLS com a variável dependente transformada por
#Box-Cox

modelo_bc = sm.OLS.from_formula('bc_violations ~ staff + post + corruption',
                                df_corruption).fit()

# Parâmetros do 'modelo_bc'
modelo_bc.summary()

#%%
# Teste de Shapiro-Francia nos resíduos do 'modelo_bc'

shapiro_francia(modelo_bc.resid)

# In[]: Gráfico para a comparação dos LogLiks dos modelos Poisson,
#binomial negativo, ZIP, ZINB e modelo OLS com trasnformação de Box-Cox

# Definição do dataframe com os modelos e respectivos LogLiks
df_llf = pd.DataFrame({'modelo':['Poisson','ZIP','BNeg','ZINB',
                                 'OLS Linear','OLS Box-Cox'],
                      'loglik':[modelo_poisson.llf,
                                modelo_zip.llf,
                                modelo_bneg.llf,
                                modelo_zinb.llf,
                                modelo_linear.llf,
                                modelo_bc.llf]})
df_llf

# Plotagem propriamente dita
fig, ax = plt.subplots(figsize=(15,10))

c = ['indigo', 'deeppink', 'goldenrod', 'darkorange',
     'darkgreen','limegreen']

ax1 = ax.barh(df_llf.modelo,df_llf.loglik, color = c)
ax.bar_label(ax1, label_type='center', color='white', fontsize=30)
ax.set_ylabel("Modelo Proposto", fontsize=20)
ax.set_xlabel("LogLik", fontsize=20)
ax.tick_params(axis='y', labelsize=20)
ax.tick_params(axis='x', labelsize=20)
plt.show()
